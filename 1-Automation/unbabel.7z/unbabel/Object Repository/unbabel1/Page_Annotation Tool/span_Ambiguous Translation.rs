<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Ambiguous Translation</name>
   <tag></tag>
   <elementGuidId>e05caab8-d6f8-4703-a759-3c5eae58c533</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Mistranslation'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>c-MarkError__errorType__name</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ambiguous Translation</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;app-mount&quot;]/div[@class=&quot;c-AnnotateApp&quot;]/div[@class=&quot;c-AnnotateApp__main g-container&quot;]/div[@class=&quot;c-Sidebar&quot;]/div[@class=&quot;c-Sidebar__item is-active&quot;]/div[@class=&quot;c-Sidebar__panel&quot;]/div[@class=&quot;c-MarkError&quot;]/ol[@class=&quot;c-MarkError__list is-active&quot;]/li[@class=&quot;c-MarkError__item is-open&quot;]/ol[@class=&quot;c-MarkError__subList&quot;]/li[@class=&quot;c-MarkError__item is-open&quot;]/ol[@class=&quot;c-MarkError__subList&quot;]/li[@class=&quot;c-MarkError__item is-selectable&quot;]/div[@class=&quot;c-MarkError__errorType&quot;]/span[@class=&quot;c-MarkError__errorType__name&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mistranslation'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other POS Omitted'])[1]/following::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Named Entity'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='False Friend'])[1]/preceding::span[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//li/ol/li[3]/ol/li/div/span</value>
   </webElementXpaths>
</WebElementEntity>
