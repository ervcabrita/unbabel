import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://staging.annotation.tools.unbabel.com/')

WebUI.click(findTestObject('Page_Annotation Tool/button_Sign In'))

WebUI.setText(findTestObject('Page_Annotation Tool/input_Username_username'), 'emanuel+annotator2')

WebUI.setEncryptedText(findTestObject('Page_Annotation Tool/input_Password_password'), 'WM8AAaMCudsr3ue4Oktwww==')

WebUI.delay(120)

WebUI.click(findTestObject('Page_Annotation Tool/button_Sign in (1)'))

WebUI.click(findTestObject('Page_Annotation Tool  Home/a_EN to ES'))

WebUI.delay(4)

WebUI.click(findTestObject('Page_Annotation Tool/span_Back_c-TopBar__circle is-'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Annotation Tool/p_HolaLa situacin que explicas'))

WebUI.setText(findTestObject('Page_Annotation Tool/input_Highlight target text_se'), 'Omitted Preposition')

WebUI.sendKeys(findTestObject('Page_Annotation Tool/input_Highlight target text_se'), Keys.chord(Keys.ENTER))

WebUI.click(findTestObject('Page_Annotation Tool/span_Omitted Preposition'))

WebUI.click(findTestObject('Page_Annotation Tool/button_Add'))

WebUI.click(findTestObject('Page_Annotation Tool/div_-  Finish or Report'))

WebUI.setText(findTestObject('Page_Annotation Tool/textarea_Report_comment'), 'done')

WebUI.click(findTestObject('Page_Annotation Tool/button_Finish'))

WebUI.click(findTestObject('Page_Annotation Tool/button_Yes'))

WebUI.click(findTestObject('Page_Annotation Tool/button_Back'))

WebUI.click(findTestObject('Page_Annotation Tool  Home/button_Hi Emanuelannotator2'))

WebUI.click(findTestObject('Page_Annotation Tool  Home/a_Logout'))

WebUI.closeBrowser()

